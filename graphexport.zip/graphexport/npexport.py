import numpy as np
import cv2 as cv


graph = cv.imread("../Graphs_neu/Nian.png")
# Generate some test data

x = graph.shape

x = list(x)
print(x)
graph = graph.reshape(x)


# Write the array to disk
with open('../Graphs_neu/Nian.txt', 'w') as outfile:
    # I'm writing a header here just for the sake of readability
    # Any line starting with "#" will be ignored by numpy.loadtxt
    #outfile.write('# Array shape: {0}\n'.format(join1.shape))
    
    # Iterating through a ndimensional array produces slices along
    # the last axis. This is equivalent to data[i,:,:] in this case
    for data_slice in graph:

        # The formatting string indicates that I'm writing out
        # the values in left-justified columns 7 characters in width
        # with 2 decimal places.  
        np.savetxt(outfile, data_slice, fmt='%4d')

        # Writing out a break to indicate different slices...
        outfile.write('# New slice\n')
        

# Read the array from disk

new_data = np.loadtxt('../Graphs_neu/Nian.txt')
#new_data1 = new_data.reshape((35,50,3))
new_data1 = np.array(new_data).reshape(x)


new_data1 = new_data1.astype(np.uint8)
#new_data1 = np.array(new_data1)
#print(graph[0:2], "Graph1")
#print(type(graph[0][0][0]))
#print(new_data1[0:2], "Neu")
#print(type(graph[0][0][0]))
#print(type(new_data1[0][0][0]))


cv.imshow("Neuer Graph", new_data1)
cv.waitKey(0)
cv.destroyAllWindows

cv.imshow("Alter Graph",graph)
cv.waitKey(0)
cv.destroyAllWindows
